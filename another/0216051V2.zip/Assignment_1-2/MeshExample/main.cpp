#include "mesh.h"
#include "FreeImage.h"
#include "glew.h"
#include "glut.h"

#include <vector>
#define SCENCE "park.scene"
#define LIGHT "park.light"
#define VIEW "park.view"
struct node
{
	mesh *object;
	GLfloat scale[3], rotation[4], transfer[3];
	GLuint start, end;
	char texttype[100];
};
std::vector<node> objects;
GLuint windowSize[2], x, y, select = 0, c_state = 0, org_x, org_y, res;
GLfloat eye[3], vat[3], vup[3], fovy, dnear, dfar, r, angle;
GLuint texObject[100],num_tex=0,pre_num_tex=0,cub_num=0;
char texName[100][100], texName_type[100][100], texttype[100], cube[100][6][100];


void light();
void display();
void init();
void reshape(GLsizei , GLsizei );
void drawobject(int);
void keyboard(unsigned char, int, int);
void mousefun(int, int, int, int);
void mousePassiveMotion(int, int);
void mouseMotion(int, int);

void LoadTexture(char* pFilename, int iIndex);
void LoadcubeTexture(int cubindex, int iIndex);
void LoadSense();
int main(int argc, char** argv)
{
	init();
	LoadSense();
	glutInit(&argc, argv);
	glutInitWindowSize(windowSize[0], windowSize[1]);
	glutInitWindowPosition(0, 0);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutCreateWindow("Assignment 1");
	glewInit();
	FreeImage_Initialise();
	glGenTextures(num_tex, texObject);
	int curr_cub = 0;
	for (int i = 0; i < num_tex; i++)
	{
		if (strcmp(texName_type[i], "cube-map") == 0)
			LoadcubeTexture(curr_cub++, i);
		else LoadTexture(texName[i], i);
	}
		
	FreeImage_DeInitialise();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutMotionFunc(mouseMotion);
	glutMouseFunc(mousefun);
	glutPassiveMotionFunc(mousePassiveMotion);
	glutMainLoop();
	return 0;
}
void light()
{
	glShadeModel(GL_SMOOTH);
	
	// z buffer enable
	glEnable(GL_DEPTH_TEST);

	// enable lighting
	glEnable(GL_LIGHTING);

	FILE *fp;
	fp = fopen(LIGHT, "r");
	char type[20];
	unsigned short index = GL_LIGHT0;
	GLfloat x,y,z;
	while (fscanf(fp, "%s",type) == 1)
	{
		if (strcmp(type, "light") == 0)
		{
			glEnable(index);
			res = fscanf(fp, "%f%f%f", &x, &y, &z);
			GLfloat light_position[] = { x, y, z, 1.0 };
			glLightfv(index, GL_POSITION, light_position);

			res = fscanf(fp, "%f%f%f", &x, &y, &z);
			GLfloat light_ambient[] = { x, y, z, 1.0 };
			glLightfv(index, GL_AMBIENT, light_ambient);


			res = fscanf(fp, "%f%f%f", &x, &y, &z);
			GLfloat light_diffuse[] = { x, y, z, 1.0 };
			glLightfv(index, GL_DIFFUSE, light_diffuse);

			index ++;
		}
		else
		{
			res = fscanf(fp, "%f%f%f", &x, &y, &z);
			GLfloat ambient[] = { x, y, z };
			glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
		}
	}
	fclose(fp);
	



	

}
void display()
{
	// clear the buffer
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);      //�M����color
	glClearDepth(1.0f);                        // Depth Buffer (�N�Oz buffer) Setup
	glEnable(GL_DEPTH_TEST);				   // Enables Depth Testing
	glDepthFunc(GL_LEQUAL);                    // The Type Of Depth Test To Do
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//�o���e���M���¦�åB�M��z buffer

	// viewport transformation
	glViewport(x, y, windowSize[0], windowSize[1]);

	// projection transformation
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fovy, (GLfloat)windowSize[0] / (GLfloat)windowSize[1], dnear, dfar);
	// viewing and modeling transformation
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(vat[0] + sin(angle)*r, eye[1], vat[2] + cos(angle)*r,// eye
		vat[0], vat[1], vat[2],     // center
		vup[0], vup[1], vup[2]);    // up

	//�`�Nlight��m���]�w�A�n�bgluLookAt����
	light();

	for (int i = 0; i < objects.size();i++)
	{
		glPushMatrix();
		glTranslatef(objects[i].transfer[0], objects[i].transfer[1], objects[i].transfer[2]);
		glRotatef(objects[i].rotation[0], objects[i].rotation[1], objects[i].rotation[2], objects[i].rotation[3]);
		glScalef(objects[i].scale[0], objects[i].scale[1], objects[i].scale[2]);
		if (strcmp(objects[i].texttype, "single-texture") == 0)
		{
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, texObject[objects[i].start]);
			glEnable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GREATER, 0.5f);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		}
		else if (strcmp(objects[i].texttype, "multi-texture") == 0)
		{
			glDisable(GL_ALPHA_TEST);
			for (int j = objects[i].start; j < objects[i].end; j++)
			{
				glActiveTexture(GL_TEXTURE0 + j - objects[i].start);
				glEnable(GL_TEXTURE_2D);
				glBindTexture(GL_TEXTURE_2D, texObject[j]);
				glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
				glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
			}
		}
		else if (strcmp(objects[i].texttype, "cube-map") == 0)
		{
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
			glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glEnable(GL_TEXTURE_GEN_R);
			glEnable(GL_TEXTURE_CUBE_MAP);
			glBindTexture(GL_TEXTURE_CUBE_MAP, texObject[objects[i].start]);
			glEnable(GL_ALPHA_TEST);
			glAlphaFunc(GL_GREATER, 0.5f);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		}
		drawobject(i);
		if (strcmp(objects[i].texttype, "multi-texture") == 0)
		{
			for (int j = objects[i].end -1 ; j >= objects[i].start; j--)
			{
				glActiveTexture(GL_TEXTURE0 + j - objects[i].start);
				glDisable(GL_TEXTURE_2D);
				glBindTexture(GL_TEXTURE_2D, 0);
			}
		}
		else if (strcmp(objects[i].texttype, "cube-map") == 0)
		{
			glDisable(GL_TEXTURE_GEN_S);
			glDisable(GL_TEXTURE_GEN_T);
			glDisable(GL_TEXTURE_GEN_R);
			glDisable(GL_TEXTURE_CUBE_MAP);
		}
		glPopMatrix();
	}
	glutSwapBuffers();
}
void reshape(GLsizei w, GLsizei h)
{
	windowSize[0] = w;
	windowSize[1] = h;
}
void init()
{
	objects.clear();
	FILE *fp;
	fp = fopen(VIEW, "r");
	char type[20];
	while (fscanf(fp, "%s", type) == 1)
	{

		if (strcmp(type, "eye") == 0)
			fscanf(fp, "%f%f%f", &eye[0], &eye[1], &eye[2]);
		else if (strcmp(type, "vat") == 0)
			fscanf(fp, "%f%f%f", &vat[0], &vat[1], &vat[2]);
		else if (strcmp(type, "vup") == 0)
			fscanf(fp, "%f%f%f", &vup[0], &vup[1], &vup[2]);
		else if (strcmp(type, "fovy") == 0)
			fscanf(fp, "%f", &fovy);
		else if (strcmp(type, "dnear") == 0)
			fscanf(fp, "%f", &dnear);
		else if (strcmp(type, "dfar") == 0)
			fscanf(fp, "%f", &dfar);
		else
			fscanf(fp, "%d%d%d%d", &x, &y, &windowSize[0], &windowSize[1]);
	}
	fclose(fp);
	r = sqrt((eye[0] - vat[0])*(eye[0] - vat[0]) + (eye[2] - vat[2]) * (eye[2] - vat[2]));
	angle = atan((eye[0] - vat[0]) / (eye[2] - vat[2]));
}
void LoadSense()
{
	FILE *fp;
	fp = fopen(SCENCE, "r");
	char name[100];
	while (fscanf(fp, "%s", name) == 1)
	{
		if (strcmp(name, "cube-map") == 0)
		{
			strcpy(texttype, name);
			pre_num_tex = num_tex;
			for (int i = 0; i < 6; i++)
			{
				fscanf(fp, "%s", name);
				strcpy(cube[cub_num][i], name);
			}
			cub_num++;
			strcpy(texName_type[num_tex], "cube-map");
			strcpy(texName[num_tex++], "ya");
			fscanf(fp, "%s", name);
		}
		else if (strcmp(name, "single-texture") == 0)
		{
			strcpy(texttype, name);
			pre_num_tex = num_tex;
			strcpy(texName_type[num_tex], "single-texture");
			fscanf(fp, "%s", texName[num_tex++]);
			fscanf(fp, "%s", name);

		}
		else if (strcmp(name, "multi-texture") == 0)
		{
			strcpy(texttype, name);
			pre_num_tex = num_tex;
			fscanf(fp, "%s", name);
			while (strcmp(name, "model") != 0)
			{
				strcpy(texName_type[num_tex], "multi-texture");
				strcpy(texName[num_tex++], name);
				fscanf(fp, "%s", name);
			}

		}
		else if (strcmp(name, "no-texture") == 0)
		{
			strcpy(texttype, name);
			fscanf(fp, "%s", name);
		}
			
		fscanf(fp, "%s", name);
		node tmp;
		tmp.object = new mesh(name);
		tmp.start = pre_num_tex;
		tmp.end = num_tex;
		strcpy(tmp.texttype, texttype);
		res = fscanf(fp, "%f%f%f", &tmp.scale[0], &tmp.scale[1], &tmp.scale[2]);
		res = fscanf(fp, "%f%f%f%f", &tmp.rotation[0], &tmp.rotation[1], &tmp.rotation[2], &tmp.rotation[3]);
		res = fscanf(fp, "%f%f%f", &tmp.transfer[0], &tmp.transfer[1], &tmp.transfer[2]);
		objects.push_back(tmp);
	}


}
void drawobject(int index)
{
	int lastMaterial = -1;
	for (size_t i = 0; i < objects[index].object->fTotal; ++i)
	{
		// set material property if this face used different material
		if (lastMaterial != objects[index].object->faceList[i].m)
		{
			lastMaterial = (int)objects[index].object->faceList[i].m;
			glMaterialfv(GL_FRONT, GL_AMBIENT, objects[index].object->mList[lastMaterial].Ka);
			glMaterialfv(GL_FRONT, GL_DIFFUSE, objects[index].object->mList[lastMaterial].Kd);
			glMaterialfv(GL_FRONT, GL_SPECULAR, objects[index].object->mList[lastMaterial].Ks);
			glMaterialfv(GL_FRONT, GL_SHININESS, &objects[index].object->mList[lastMaterial].Ns);

			//you can obtain the texture name by object->mList[lastMaterial].map_Kd
			//load them once in the main function before mainloop
			//bind them in display function here
		}
		
		

		glBegin(GL_TRIANGLES);
		for (size_t j = 0; j<3; ++j)
		{
			if (strcmp(objects[index].texttype, "single-texture") == 0 || strcmp(objects[index].texttype, "cube-map") == 0 )
				glTexCoord3fv(objects[index].object->tList[objects[index].object->faceList[i][j].t].ptr);
			else if (strcmp(objects[index].texttype, "multi-texture") == 0)
			{
				for (int k = objects[index].start; k < objects[index].end; k++)
					glMultiTexCoord3fv(GL_TEXTURE0 + k - objects[index].start, objects[index].object->tList[objects[index].object->faceList[i][j].t].ptr);
			}
			glNormal3fv(objects[index].object->nList[objects[index].object->faceList[i][j].n].ptr);
			glVertex3fv(objects[index].object->vList[objects[index].object->faceList[i][j].v].ptr);
		}
		glEnd();
		
		
		
	}
}
void keyboard(unsigned char key, int x, int y)
{

	switch (key)
	{
		case 'w':
			fovy += 10;
			glutPostRedisplay();
			break;
		case 'a':   
			angle += 0.5;
			glutPostRedisplay();
			break;
		case 's': 
			fovy -= 10;
			glutPostRedisplay();
			break;
		case 'd': 
			angle -= 0.5;
			glutPostRedisplay();
			break;
		default:
			if (key >= '0'&&key <= '9') select = key - '0';
			if (key >= objects.size() + '0') select = objects.size() - 1;
			break;
	}
	
}
void mousefun(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		org_x = x;
		org_y = y;
		c_state = 1;
	}
		
}
void mouseMotion(int x, int y)
{
	if (c_state)
	{
		objects[select].transfer[0] += (GLfloat)(x - org_x)/100;
		objects[select].transfer[1] -= (GLfloat)(y - org_y) / 100;
		org_x = x;
		org_y = y;
		//printf("%f %f\n", objects[select].transfer[0], objects[select].transfer[1]);
		glutPostRedisplay();
	}
}
void mousePassiveMotion(int x, int y)
{
	c_state = 0;
}
void LoadTexture(char* pFilename, int iIndex)
{
	FIBITMAP* pImage = FreeImage_Load(FreeImage_GetFileType(pFilename, 0), pFilename);
	FIBITMAP *p32BitsImage = FreeImage_ConvertTo32Bits(pImage);
	int iWidth = FreeImage_GetWidth(p32BitsImage);
	int iHeight = FreeImage_GetHeight(p32BitsImage);

	glBindTexture(GL_TEXTURE_2D, texObject[iIndex]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, iWidth, iHeight,
		0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(p32BitsImage));
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	FreeImage_Unload(p32BitsImage);
	FreeImage_Unload(pImage);

	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
}

void LoadcubeTexture(int cubindex, int iIndex)
{
	

	glBindTexture(GL_TEXTURE_CUBE_MAP, texObject[iIndex]);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	for (int i = 0; i < 6; i++)
	{
		FIBITMAP* pImage = FreeImage_Load(FreeImage_GetFileType(cube[cubindex][i], 0), cube[cubindex][i]);
		FIBITMAP *p32BitsImage = FreeImage_ConvertTo32Bits(pImage);
		int iWidth = FreeImage_GetWidth(p32BitsImage);
		int iHeight = FreeImage_GetHeight(p32BitsImage);
		
		glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X+i, 0, GL_RGBA, iWidth, iHeight,
			0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(p32BitsImage));

		FreeImage_Unload(p32BitsImage);
		FreeImage_Unload(pImage);
	}
	
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glGenerateMipmap(GL_TEXTURE_CUBE_MAP);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
}